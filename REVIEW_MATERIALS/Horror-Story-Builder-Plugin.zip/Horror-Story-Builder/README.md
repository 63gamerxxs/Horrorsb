# Horror Story Builder v3.0.0 (self-contained)
`/horrorsb` → five concepts → pick one → full production → `VIDEO_PROJECTS` on Google Drive.
Commands: `/horrorsb`, `/horrorsb-new`, `/horrorsb-continue`, `/horrorsb-status`.

What changed from v2.1.0: no reference videos needed; the style (measured from the three reference clips) is encoded as a style bible plus a working Three.js engine (smooth poly characters, first-person rig with phone REST/READ poses, chat-phone UI, light/atmosphere/water/post kit, deterministic frame renderer), a hook/retention grammar, an audio bible with mix/QC tools, original fonts (Bebas Neue, Barlow Condensed, DM Sans — OFL, bundled), ElevenLabs voice workflow, and a post-mortem of the doorbell_cam_ep1 failures turned into rules.

Setup: `cd engine && npm install` (three, puppeteer-core, bundled Chromium fallback), ffmpeg, python3+numpy. Run `bash tools/preflight.sh`. Needs the ElevenLabs and Google Drive connectors in the Claude account that runs it.
Smoke test: `cd engine && npm run smoke` (renders 3 s preview). Tested in a software-WebGL sandbox; full 85 s renders on CPU-only machines are slow — use `--scale 0.6667` or a GPU (`HSB_GPU=1`).
Fonts: see fonts/OFL.txt (SIL Open Font License).
