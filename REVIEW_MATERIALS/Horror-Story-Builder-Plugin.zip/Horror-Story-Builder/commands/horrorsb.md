---
description: Start Horror Story Builder v3 — five original concepts, then full production after you pick one.
---
Use the `horror-story-builder` skill. Do NOT ask for reference videos (the style is built in). If no project is selected: read references/concept-seeds.md and output exactly five original concepts (title, premise, main mystery, 5-second hook, suspense engine, two contradicting sources, ending choice pair), then STOP and wait for the user's pick or "five more". If the user already picked: run the production pipeline in references/pipeline.md, saving to Google Drive VIDEO_PROJECTS after every milestone.
