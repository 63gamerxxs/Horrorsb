---
description: Continue a saved project from its NEXT ACTION, or write the next episode after a viewer choice.
---
Use the `horror-story-builder` skill. Read project-state.md and story-bible.md (Drive VIDEO_PROJECTS, else local). Resume exactly at NEXT ACTION. If the user gives a chosen branch, build Part N+1 with the "PART N+1 / You chose: …" card, continuing from that branch only.
