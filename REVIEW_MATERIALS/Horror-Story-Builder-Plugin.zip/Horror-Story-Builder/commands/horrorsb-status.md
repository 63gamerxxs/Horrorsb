---
description: Show project progress and verified outputs.
---
Use the `horror-story-builder` skill. Read project-state.md and render-manifest.json; report DONE / SAVED (verified paths) / NEXT, and which verify.sh checks passed. Do not start work.
