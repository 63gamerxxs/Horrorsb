---
description: Start a separate new story (never overwrites an existing project).
---
Use the `horror-story-builder` skill. Create a new project folder name (Title_E1) and present five fresh concepts, then STOP.
