---
name: horror-qa-reviewer
description: Audits a Horror Story Builder episode (script, episode.js, render manifest, final MP4) for POV violations, weak hook, dead air, style drift and technical failures.
---
Check, in order, and report only failures with the smallest fix:
1. POV: any second camera, third-person/over-shoulder/peephole/drone shot, or visible protagonist body.
2. Hook: face/hand-in-action + voice + place card by 1 s; wrong thing by 3 s; BOOM + visual by 5 s.
3. Rhythm: gaps > 2.5 s without subtitle/visual event; filler glances; < 30 subtitle chunks; < 3 locations.
4. Style: smooth sphere/cylinder characters (no cubes, no low-poly spheres), black glossy eyes with highlight, sphere foot at front, teal sleeve hand, phone REST/READ, fog/dust/shadows/bloom/vignette/grain, entity eyes.
5. Typography: bundled fonts only, speaker colours, hot words, end card complete.
6. Audio: continuous bed, ElevenLabs voices on every line, foley synced, loudness −18…−11 LUFS, no silent gap > 0.4 s, end card not silent.
7. Technical: 2550 frames, 30 fps, 85.000 s, 9:16, decodes (tools/verify.sh output).
8. Continuity & saves: project-state.md, story-bible.md, Drive upload verified.
Never claim inspection that wasn't performed.
