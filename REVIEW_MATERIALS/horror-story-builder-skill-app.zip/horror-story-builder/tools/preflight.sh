#!/usr/bin/env bash
# One-shot environment check for Horror Story Builder.
d="$(cd "$(dirname "$0")/.." && pwd)"
chk(){ if eval "$2" >/dev/null 2>&1; then echo "OK   $1"; else echo "MISS $1  -> $3"; fi; }
chk node "node -e 'process.exit(parseInt(process.versions.node)<18?1:0)'" "install Node 18+"
chk ffmpeg "ffmpeg -version" "install ffmpeg"
chk "python3+numpy" "python3 -c 'import numpy'" "pip install numpy"
chk "engine deps" "test -d $d/engine/node_modules/three" "cd $d/engine && npm install"
chk "browser for WebGL" "test -n \"\$CHROME_PATH\" -o -x /usr/bin/google-chrome -o -x /usr/bin/chromium -o -d $d/engine/node_modules/@sparticuz/chromium" "set CHROME_PATH or npm install"
chk "ELEVENLABS_API_KEY (or use the ElevenLabs connector)" "test -n \"\$ELEVENLABS_API_KEY\"" "optional if the connector is installed"
echo "Also check connectors via tool_search: elevenlabs, google drive."
