#!/usr/bin/env python3
"""Procedural SFX fallback (numpy only) for when ElevenLabs sound generation is unavailable, plus layers that always help
(sub-bass, room tone, fluorescent hum). 48 kHz, 16-bit mono WAV. Deterministic via --seed.
  python3 synth_sfx.py kit --out audio/sfx          # writes the whole default kit
  python3 synth_sfx.py footstep --out s.wav --surface tile
"""
import argparse, os, wave, numpy as np
SR = 48000

def _rng(seed): return np.random.default_rng(seed)
def _t(d): return np.arange(int(SR * d)) / SR
def _lp(x, fc, order=2):
    # simple one-pole cascade low-pass
    a = np.exp(-2 * np.pi * fc / SR); y = x.copy()
    for _ in range(order):
        out = np.empty_like(y); s = 0.0
        for i in range(len(y)): s = (1 - a) * y[i] + a * s; out[i] = s
        y = out
    return y
def _fast_lp(x, fc):  # FFT brickwall-ish, much faster for long buffers
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR); X *= 1 / (1 + (f / fc) ** 4); return np.fft.irfft(X, len(x))
def _hp(x, fc): return x - _fast_lp(x, fc)
def _bp(x, lo, hi): return _fast_lp(_hp(x, lo), hi)
def _env(n, a=0.005, d=0.2, curve=3.0):
    t = np.arange(n) / SR; e = np.minimum(t / max(a, 1e-4), 1) * np.exp(-t / max(d, 1e-3) * curve / 3); return e
def _norm(x, peak=0.9): m = np.max(np.abs(x)) + 1e-9; return x / m * peak
def write(path, x):
    x = np.clip(x, -1, 1); os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with wave.open(path, 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype('<i2').tobytes())

def drone(dur=30, f0=46, seed=1):
    r = _rng(seed); t = _t(dur); x = 0
    for k, (m, g) in enumerate([(1, 1.0), (1.503, 0.45), (2.0, 0.35), (2.99, 0.12)]):
        det = 1 + 0.003 * r.standard_normal(); lfo = 1 + 0.15 * np.sin(2 * np.pi * (0.05 + 0.03 * k) * t + r.uniform(0, 6))
        x = x + g * np.sin(2 * np.pi * f0 * m * det * t + 0.4 * np.sin(2 * np.pi * 0.11 * t)) * lfo
    n = _fast_lp(r.standard_normal(len(t)), 220) * 0.6; x = x + n * (0.6 + 0.4 * np.sin(2 * np.pi * 0.07 * t))
    return _norm(x, 0.7)
def room_tone(dur=30, seed=2, tone=60):
    r = _rng(seed); n = _fast_lp(r.standard_normal(int(SR * dur)), 700); t = _t(dur); hum = 0.15 * np.sin(2 * np.pi * tone * t) + 0.05 * np.sin(2 * np.pi * tone * 2 * t)
    return _norm(n * 0.8 + hum, 0.5)
def fluorescent(dur=30, seed=3):
    t = _t(dur); r = _rng(seed); x = sum(a * np.sin(2 * np.pi * 100 * k * t + k) for k, a in [(1, 1), (2, 0.5), (3, 0.3), (5, 0.12)]); x += 0.08 * _hp(r.standard_normal(len(t)), 3000)
    x *= 1 + 0.05 * np.sin(2 * np.pi * 0.4 * t); return _norm(x, 0.35)
def heartbeat(dur=10, bpm=70, seed=4):
    n = int(SR * dur); x = np.zeros(n); per = 60 / bpm
    for i in range(int(dur / per) + 1):
        for off, g in [(0, 1.0), (0.28 * per, 0.65)]:
            s = int((i * per + off) * SR); L = int(0.16 * SR); tt = np.arange(L) / SR
            if s + L < n: x[s:s + L] += g * np.sin(2 * np.pi * (58 - 120 * tt) * tt) * np.exp(-tt * 28)
    return _norm(x, 0.9)
def footstep(surface='tile', weight=1.0, seed=5):
    r = _rng(seed); d = 0.28; n = int(SR * d); tt = np.arange(n) / SR; thud = np.sin(2 * np.pi * (95 - 180 * tt) * tt) * np.exp(-tt * 26) * weight
    click = _bp(r.standard_normal(n), 1500 if surface == 'tile' else 400, 6000 if surface == 'tile' else 1800) * np.exp(-tt * (70 if surface == 'tile' else 35)) * (0.5 if surface == 'tile' else 0.25)
    return _norm(thud + click, 0.8)
def door_creak(dur=2.2, seed=6):
    r = _rng(seed); t = _t(dur); f = 220 + 160 * np.sin(2 * np.pi * 0.7 * t) * t / dur + 90 * t; ph = 2 * np.pi * np.cumsum(f) / SR
    x = (np.sign(np.sin(ph)) * 0.4 + np.sin(ph * 2.02) * 0.3) * (0.4 + 0.6 * np.abs(np.sin(2 * np.pi * 6 * t + r.uniform(0, 6)))); x = _bp(x + 0.2 * r.standard_normal(len(t)), 300, 2500)
    return _norm(x * np.minimum(t / 0.1, 1) * np.minimum((dur - t) / 0.4, 1), 0.7)
def impact(dur=1.6, seed=7):  # sub boom + noise crack: the "BOOM" for hook beats / reveals
    r = _rng(seed); t = _t(dur); boom = np.sin(2 * np.pi * (70 - 38 * np.minimum(t, 0.6) / 0.6) * t) * np.exp(-t * 3.2); crack = _bp(r.standard_normal(len(t)), 200, 5000) * np.exp(-t * 14) * 0.9
    return _norm(boom + crack, 0.95)
def door_slam(seed=8): x = impact(1.2, seed); return _norm(x + 0.5 * _bp(_rng(seed).standard_normal(len(x)), 100, 900) * np.exp(-_t(1.2) * 9), 0.95)
def phone_buzz(n=2, seed=9):
    r = _rng(seed); out = []
    for i in range(n):
        t = _t(0.38); x = np.sign(np.sin(2 * np.pi * 168 * t)) * 0.4 + np.sin(2 * np.pi * 336 * t) * 0.15; x = _fast_lp(x, 900) * np.minimum(t / 0.01, 1) * np.minimum((0.38 - t) / 0.03, 1); out += [x, np.zeros(int(SR * 0.18))]
    return _norm(np.concatenate(out), 0.8)
def notif(seed=10):
    t = _t(0.55); x = np.sin(2 * np.pi * 1318 * t) * np.exp(-t * 9) + 0.7 * np.sin(2 * np.pi * 1760 * np.maximum(t - 0.09, 0)) * (t > 0.09) * np.exp(-(t - 0.09) * 8); return _norm(x, 0.55)
def tap(seed=11): r = _rng(seed); t = _t(0.06); return _norm(_bp(r.standard_normal(len(t)), 1800, 5200) * np.exp(-t * 90), 0.5)
def whoosh(dur=1.2, seed=12): r = _rng(seed); t = _t(dur); n = r.standard_normal(len(t)); c = 400 + 3500 * np.sin(np.pi * t / dur); return _norm(_bp(n, 150, 4500) * np.sin(np.pi * t / dur) ** 2 * (0.5 + 0.5 * np.sin(2 * np.pi * 2 * t)), 0.6)
def riser(dur=4.0, seed=13):
    r = _rng(seed); t = _t(dur); n = r.standard_normal(len(t)); g = (t / dur) ** 2; tone = np.sin(2 * np.pi * np.cumsum(80 + 900 * (t / dur) ** 2) / SR) * 0.25
    return _norm((_bp(n, 300, 6000) * 0.6 + tone) * g, 0.8)
def cloth(dur=0.5, seed=14): r = _rng(seed); t = _t(dur); return _norm(_bp(r.standard_normal(len(t)), 800, 5000) * np.sin(np.pi * t / dur) ** 2 * (0.5 + 0.5 * r.random(len(t)) ** 3), 0.4)
def drip(seed=15): t = _t(0.3); return _norm(np.sin(2 * np.pi * (900 + 1400 * t) * t) * np.exp(-t * 22), 0.5)
def water_lap(dur=20, seed=16): r = _rng(seed); t = _t(dur); n = _bp(r.standard_normal(len(t)), 200, 2500); return _norm(n * (0.4 + 0.6 * np.sin(2 * np.pi * 0.17 * t) ** 2), 0.45)
def whisper_sting(dur=2.5, seed=17):
    r = _rng(seed); t = _t(dur); x = sum(np.sin(2 * np.pi * f * t + r.uniform(0, 6)) for f in [311, 330, 466, 740, 1175]) * 0.15; x += _bp(r.standard_normal(len(t)), 2500, 7000) * 0.35; x *= np.sin(np.pi * np.minimum(t / dur, 1)) ** 1.5
    return _norm(x, 0.6)
def scrape(dur=1.8, seed=18): r = _rng(seed); t = _t(dur); return _norm(_bp(r.standard_normal(len(t)), 120, 1200) * (0.5 + 0.5 * np.sin(2 * np.pi * 3 * t)) * np.sin(np.pi * t / dur), 0.6)
def breath_low(dur=3.0, seed=19): r = _rng(seed); t = _t(dur); return _norm(_bp(r.standard_normal(len(t)), 200, 1800) * (np.sin(np.pi * ((t * 0.5) % 1.0)) ** 2) * 0.7, 0.35)
def static_burst(dur=0.5, seed=20): r = _rng(seed); t = _t(dur); return _norm(_hp(r.standard_normal(len(t)), 1000) * np.exp(-t * 4) * (r.random(len(t)) > 0.3), 0.5)

KIT = {k: v for k, v in dict(drone=drone, room_tone=room_tone, fluorescent=fluorescent, heartbeat=heartbeat, footstep_tile=lambda: footstep('tile'), footstep_carpet=lambda: footstep('carpet', 0.8),
    door_creak=door_creak, impact=impact, door_slam=door_slam, phone_buzz=phone_buzz, notif=notif, tap=tap, whoosh=whoosh, riser=riser, cloth=cloth, drip=drip, water_lap=water_lap,
    whisper_sting=whisper_sting, scrape=scrape, breath_low=breath_low, static_burst=static_burst).items()}
if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('name'); ap.add_argument('--out', default='.'); ap.add_argument('--dur', type=float); ap.add_argument('--seed', type=int); ap.add_argument('--surface')
    a = ap.parse_args()
    if a.name == 'list': print(' '.join(KIT)); raise SystemExit
    if a.name == 'kit':
        for k, fn in KIT.items(): write(os.path.join(a.out, k + '.wav'), fn())
        print('wrote', len(KIT), 'files to', a.out); raise SystemExit
    kw = {k: v for k, v in dict(dur=a.dur, seed=a.seed).items() if v is not None}
    if a.name == 'footstep': write(a.out, footstep(a.surface or 'tile', **({'seed': a.seed} if a.seed else {})))
    else: write(a.out, KIT[a.name](**kw) if kw else KIT[a.name]())
    print('wrote', a.out)
