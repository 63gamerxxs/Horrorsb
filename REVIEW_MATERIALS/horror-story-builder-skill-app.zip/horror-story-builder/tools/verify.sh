#!/usr/bin/env bash
# Hard QC gate. usage: verify.sh final.mp4   -> exit 1 on any failure
set -u; f="$1"; fail=0
read -r w h fps dur nb < <(ffprobe -v error -select_streams v:0 -count_frames -show_entries stream=width,height,avg_frame_rate,nb_read_frames,duration -of csv=p=0 "$f" | tr ',' ' ')
adur=$(ffprobe -v error -select_streams a:0 -show_entries stream=duration -of csv=p=0 "$f")
echo "video ${w}x${h} fps=$fps frames=$nb vdur=$dur adur=$adur"
[ "$((w*16))" = "$((h*9))" ] || { echo "FAIL not 9:16"; fail=1; }
[ "$fps" = "30/1" ] || { echo "FAIL fps"; fail=1; }
[ "$nb" = "2550" ] || { echo "FAIL frames != 2550"; fail=1; }
python3 - "$adur" <<'PY' || fail=1
import sys; a=float(sys.argv[1]); print('audio ok' if abs(a-85)<0.03 else f'FAIL audio {a}'); sys.exit(0 if abs(a-85)<0.03 else 1)
PY
# loudness + silence: no digital silence >0.4 s anywhere (end card included)
ffmpeg -v info -i "$f" -af "ebur128=peak=true,silencedetect=n=-50dB:d=0.4" -f null - 2>&1 | grep -E "silence_start|I:  |Peak:" | tail -6
n=$(ffmpeg -v info -i "$f" -af silencedetect=n=-50dB:d=0.4 -f null - 2>&1 | grep -c silence_start); [ "$n" = "0" ] || { echo "FAIL $n silent gaps"; fail=1; }
I=$(ffmpeg -v info -i "$f" -af ebur128 -f null - 2>&1 | grep -E "^\s+I:" | tail -1 | awk '{print $2}'); python3 -c "import sys;i=float('${I:-0}');print('loudness ok' if -18<=i<=-11 else 'FAIL loudness %.1f LUFS (need -18..-11)'%i);sys.exit(0 if -18<=i<=-11 else 1)" || fail=1
ffmpeg -v error -i "$f" -f null - || { echo "FAIL decode"; fail=1; }
[ $fail = 0 ] && echo "QC PASS" || { echo "QC FAIL"; exit 1; }
