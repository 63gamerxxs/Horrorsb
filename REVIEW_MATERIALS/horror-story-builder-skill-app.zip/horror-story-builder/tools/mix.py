#!/usr/bin/env python3
"""Mix dialogue + SFX + beds from a cue sheet into exactly 85.000 s stereo 48 kHz WAV (numpy only).
Inputs must be 16-bit PCM WAV (convert: ffmpeg -i in.mp3 -ar 48000 -ac 1 -c:a pcm_s16le out.wav).
cues.json: {"duration":85,
 "beds":[{"file":"drone.wav","gain_db":-24,"from":0,"to":85,"fade":1.0}],       # looped, continuous, NEVER silent
 "dialogue":[{"file":"l01.wav","t":0.4,"gain_db":0,"pan":0,"fx":"none|phone|pa|room|whisper"}],
 "sfx":[{"file":"footstep_tile.wav","t":3.2,"gain_db":-10,"pan":0.2,"repeat":{"every":0.55,"until":9.0}}],
 "duck_db":-7}
Then: ffmpeg -i mix.wav -af loudnorm=I=-14:TP=-1.5:LRA=9 final_mix.wav  (done by assemble.sh)"""
import json, sys, wave, numpy as np
SR = 48000
def rd(p):
    with wave.open(p) as w:
        assert w.getsampwidth() == 2 and w.getframerate() == SR, f'{p}: need 16-bit 48k wav'
        x = np.frombuffer(w.readframes(w.getnframes()), '<i2').astype(np.float32) / 32768
        return x.reshape(-1, w.getnchannels()).mean(1)
def fftfilt(x, lo, hi):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR); m = ((f >= lo) & (f <= hi)).astype(float); k = max(1, int(len(f) * 0.0005)); m = np.convolve(m, np.ones(k) / k, 'same'); return np.fft.irfft(X * m, len(x))
def echo(x, delay, fb, n=4):
    y = np.zeros(len(x) + int(delay * SR * n)); y[:len(x)] += x
    for i in range(1, n + 1): s = int(delay * SR * i); y[s:s + len(x)] += x * (fb ** i)
    return y
def fx(x, kind):
    if kind == 'phone': return fftfilt(x, 380, 3400) * 1.4
    if kind == 'pa': return echo(fftfilt(x, 300, 4200) * 1.5, 0.11, 0.45, 3)
    if kind == 'room': return echo(x, 0.045, 0.35, 5)
    if kind == 'whisper': return fftfilt(x, 150, 9000) * 1.2
    return x
def gain(db): return 10 ** (db / 20)
def place(buf, x, t, g, pan):
    s = int(t * SR); e = min(len(buf), s + len(x)); 
    if s >= len(buf) or e <= s: return
    x = x[:e - s] * g; l, r = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4); buf[s:e, 0] += x * l * 1.414; buf[s:e, 1] += x * r * 1.414
def main(cue_path, out):
    c = json.load(open(cue_path)); D = c.get('duration', 85); N = int(D * SR); dia = np.zeros((N, 2)); fxb = np.zeros((N, 2)); bed = np.zeros((N, 2)); dl = np.zeros(N)
    for d in c.get('dialogue', []):
        x = fx(rd(d['file']), d.get('fx', 'none')); place(dia, x, d['t'], gain(d.get('gain_db', 0)), d.get('pan', 0)); s = int(d['t'] * SR); e = min(N, s + len(x)); dl[s:e] = np.maximum(dl[s:e], 1.0)
    for s_ in c.get('sfx', []):
        x = rd(s_['file']); g = gain(s_.get('gain_db', -10)); r = s_.get('repeat')
        if r:
            t = s_['t']
            while t < r['until']: place(fxb, x, t, g * (0.85 + 0.15 * np.sin(t * 12.9)), s_.get('pan', 0) + 0.15 * np.sin(t * 3.1)); t += r['every']
        else: place(fxb, x, s_['t'], g, s_.get('pan', 0))
    for b in c.get('beds', []):
        x = rd(b['file']); a, z = int(b.get('from', 0) * SR), int(min(b.get('to', D), D) * SR); loop = np.resize(x, z - a) * gain(b.get('gain_db', -24)); f = int(b.get('fade', 1.0) * SR)
        env = np.ones(z - a); env[:f] = np.linspace(0, 1, f); env[-f:] = np.linspace(1, 0, f); loop = loop * env; bed[a:z, 0] += loop; bed[a:z, 1] += loop
    k = int(0.15 * SR); sm = np.convolve(dl, np.ones(k) / k, 'same'); duck = 1 - (1 - gain(c.get('duck_db', -7))) * sm
    mix = dia + fxb * duck[:, None] + bed * duck[:, None]; pk = np.max(np.abs(mix)) + 1e-9
    if pk > 0.95: mix *= 0.95 / pk
    with wave.open(out, 'wb') as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(mix, -1, 1) * 32767).astype('<i2').tobytes())
    print('mix', out, f'{N / SR:.3f}s peak {20 * np.log10(pk):.1f} dBFS')
if __name__ == '__main__': main(sys.argv[1], sys.argv[2])
