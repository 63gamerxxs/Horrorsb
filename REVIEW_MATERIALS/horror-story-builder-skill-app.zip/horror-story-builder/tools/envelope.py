#!/usr/bin/env python3
"""Per-frame (30 fps) loudness envelope 0..1 from a dialogue WAV -> JSON array, drives mouth open/close.  envelope.py in.wav out.json"""
import sys, wave, json, numpy as np
w = wave.open(sys.argv[1]); sr = w.getframerate(); x = np.frombuffer(w.readframes(w.getnframes()), '<i2').astype(float).reshape(-1, w.getnchannels()).mean(1) / 32768
hop = sr // 30; n = len(x) // hop; e = np.array([np.sqrt(np.mean(x[i * hop:(i + 1) * hop] ** 2)) for i in range(n)]); e = e / (np.percentile(e, 95) + 1e-9)
e = np.clip(e, 0, 1); e = np.convolve(e, [0.25, 0.5, 0.25], 'same'); json.dump([round(float(v), 3) for v in e], open(sys.argv[2], 'w'))
