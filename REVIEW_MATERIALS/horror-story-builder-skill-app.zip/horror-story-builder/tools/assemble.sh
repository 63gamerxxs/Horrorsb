#!/usr/bin/env bash
# assemble.sh video_segments.txt mix.wav final.mp4  (segments file = ffmpeg concat list). Forces exactly 85 s / 2550 frames / 1080x1920.
set -e; seg="$1"; mix="$2"; out="$3"
ffmpeg -y -loglevel error -i "$mix" -af "loudnorm=I=-14:TP=-1.5:LRA=9,apad=whole_dur=85,atrim=0:85" -ar 48000 -c:a pcm_s16le "${out%.mp4}_norm.wav"
ffmpeg -y -loglevel error -f concat -safe 0 -i "$seg" -i "${out%.mp4}_norm.wav" -map 0:v:0 -map 1:a:0 \
  -vf "scale=1080:1920:flags=lanczos,setsar=1,fps=30" -frames:v 2550 -c:v libx264 -preset medium -crf 16 -pix_fmt yuv420p -r 30 -c:a aac -b:a 192k -ar 48000 -t 85 -movflags +faststart "$out"
bash "$(dirname "$0")/verify.sh" "$out"
