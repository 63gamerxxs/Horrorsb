import * as THREE from 'three';
import { W, H, FONTS } from './lib/style.js';
import { FirstPerson } from './lib/fp.js';
import { Phone } from './lib/phone.js';
import { makePost } from './lib/post.js';
import { Overlay } from './lib/overlay.js';

const q = new URLSearchParams(location.search), scale = parseFloat(q.get('scale') || '1');
const OW = Math.round(W * scale), OH = Math.round(H * scale);
await Promise.all([`64px "${FONTS.display}"`, `800 64px "${FONTS.subtitle}"`, `600 24px "${FONTS.ui}"`, `700 24px "${FONTS.ui}"`].map((f) => document.fonts.load(f, 'AaBb0123 ‹›')));

const gl = document.getElementById('gl'), out = document.getElementById('out'); out.width = OW; out.height = OH;
const renderer = new THREE.WebGLRenderer({ canvas: gl, antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(1); renderer.setSize(OW, OH, false); renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05; renderer.outputColorSpace = THREE.SRGBColorSpace;
const scene = new THREE.Scene();

const mod = await import('/episode.js'); const ep = mod.default;
const world = await ep.build({ THREE, scene, renderer }); // returns { bodyTrack, phoneKeys, leftKeys, phoneScript, update(t,f), meta, fade?(t), phoneAmt?(t) }
const fp = new FirstPerson(scene, { bodyTrack: world.bodyTrack, ...(world.fpOpts || {}) });
const phone = new Phone(world.phoneScript); fp.attachPhone(phone); fp.setPoseTracks(world.phoneKeys, world.leftKeys);
const post = makePost(renderer, scene, fp.camera, OW, OH, { dof: scale >= 0.5 || q.get('dof') === '1' });
const overlay = new Overlay(world.meta); const ctx = out.getContext('2d'); ctx.setTransform(OW / W, 0, 0, OH / H, 0, 0);

window.__ready = true;
window.renderFrame = (i) => {
  const t = i / 30;
  fp.update(t); phone.update(t); world.update && world.update(t, i, fp);
  const amt = world.phoneKeys ? fp.poseTrack(t).amt : 0;
  post.frame(t, i, { phoneAmt: Math.max(0, (amt - 0.5) * 2), fade: world.fade ? world.fade(t) : 0 });
  ctx.clearRect(0, 0, W, H); overlay.draw(ctx, t, gl);
  return out.toDataURL('image/jpeg', 0.96).slice(23);
};
