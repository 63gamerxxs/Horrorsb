// SMOKE-TEST / PATTERN episode: corridor, red practicals, exit sign, guard-style NPC, glowing-eyed entity, phone, subtitles, end card.
import * as THREE from 'three';
import { setMood, trackSpot, exitSign, redPractical, dust, slatLight } from '/engine/lib/atmosphere.js';
import { floor, wall, ceiling, door, crate } from '/engine/lib/kit.js';
import { buildCharacter, buildEntity } from '/engine/lib/character.js';
import { PAL } from '/engine/lib/style.js';

export default {
  async build({ scene }) {
    setMood(scene, { fog: '#04080a', density: 0.05, ambient: 0.22 });
    floor(scene, 3.2, 16); ceiling(scene, 3.2, 16, 2.9);
    wall(scene, [-1.6, 0, -2], [0.2, 2.9, 16], '#4a2a2f'); wall(scene, [1.6, 0, -2], [0.2, 2.9, 16], '#4a2a2f'); wall(scene, [0, 0, -9.8], [3.4, 2.9, 0.2], '#2c3a36');
    door(scene, [0, 0, -9.6], 0, { color: '#1f2b27' }); exitSign(scene, [0, 2.45, -9.5]);
    redPractical(scene, [-1.4, 2.5, -3], 1.4); redPractical(scene, [1.4, 2.5, -6.5], 1.4);
    trackSpot(scene, [0.4, 2.8, -4.4], [0, 0, -4.4], { color: '#cfd9ff', intensity: 70, angle: 0.5 });
    crate(scene, [1.0, 0, -4.8]); crate(scene, [1.0, 0.6, -4.8], 0.5); slatLight(scene, [-1.49, 1.6, -7], 1.2, 1.4, Math.PI / 2, '#8fb0ff');
    const guard = buildCharacter({ shirt: PAL.uniformNavy, hairStyle: 'cap', hat: PAL.uniformNavy, badge: true, radio: true, skin: PAL.skin[0] }); guard.group.position.set(0, 0, -4.0); scene.add(guard.group);
    const ent = buildEntity(); ent.group.position.set(0.6, 0, -8.4); scene.add(ent.group);
    const d = dust(scene, { center: [0, 1.5, -4], bounds: [3, 2.6, 12] });
    return {
      bodyTrack: (await import('/engine/lib/tl.js')).track([[0, { x: 0, z: 0, yaw: 0, pitch: 0, walk: 1 }], [1.4, { x: 0, z: -1.2, yaw: 0, pitch: -0.05, walk: 0 }], [3, { x: 0, z: -1.2, yaw: 0, pitch: -0.1, walk: 0 }]]),
      phoneKeys: [[0, { amt: 0 }], [0.8, { amt: 0.5 }], [1.5, { amt: 1 }], [3, { amt: 1 }]], leftKeys: [[0, { vis: 0 }], [1, { vis: 0 }]],
      phoneScript: { contact: { name: 'Mara', initial: 'M', color: '#e87aa6' }, clock: () => '10:06', items: [
        { t: 0.2, side: 'in', text: 'where are you' }, { t: 0.9, side: 'in', text: 'its too dark in here', receipt: null }, { t: 1.9, side: 'out', text: 'who is this', typeFrom: 1.4, receipt: 'Read' } ] },
      update(t) { guard.pose(t, { talk: (Math.sin(t * 14) + 1) / 2 * (t < 2 ? 1 : 0) }); ent.pose(t, {}); ent.blink(Math.sin(t * 5) > -0.9); d.userData.update(t); },
      meta: { placeCard: { t0: 0, t1: 1.6, line1: 'Friday · 9:50 PM', line2: 'Harbor Lane Depot — Level B' },
        subs: [{ t0: 0.3, t1: 1.1, who: 'npc', text: 'We are safe [[here.]]' }, { t0: 1.1, t1: 1.9, who: 'hero', text: 'Who are you?!' }],
        endCardStart: 2.0, endCard: { title: 'What would\nyou do?', a: { label: 'Stay hidden', icon: 'mute', color: '#3f7d65' }, b: { label: 'Open the door', icon: 'door', color: '#a8402f' }, next: 'Part 2', handle: '@yourhandle' } }
    };
  }
};
