#!/usr/bin/env node
// Deterministic frame renderer: node render.mjs --episode <file> --out <dir> [--frames 0-2549] [--preview|--scale .5]
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import { spawn } from 'node:child_process'; import { fileURLToPath } from 'node:url'; import { createRequire } from 'node:module';
const here = path.dirname(fileURLToPath(import.meta.url)), root = path.resolve(here, '..'), require = createRequire(import.meta.url);
const arg = (k, d) => { const i = process.argv.indexOf('--' + k); return i < 0 ? d : (process.argv[i + 1]?.startsWith('--') || process.argv[i + 1] === undefined ? true : process.argv[i + 1]); };
const episode = path.resolve(arg('episode')), outDir = path.resolve(arg('out', 'out')), preview = arg('preview', false);
const scale = parseFloat(arg('scale', preview ? '0.3333' : '1')); const [f0, f1] = String(arg('frames', '0-2549')).split('-').map(Number);
fs.mkdirSync(outDir, { recursive: true });
const mime = { '.js': 'text/javascript', '.mjs': 'text/javascript', '.html': 'text/html', '.ttf': 'font/ttf', '.json': 'application/json' };
const map = (u) => u === '/' ? path.join(here, 'index.html') : u === '/episode.js' ? episode : u.startsWith('/nm/') ? path.join(here, 'node_modules', u.slice(4)) : u.startsWith('/engine/') ? path.join(here, u.slice(8)) : u.startsWith('/fonts/') ? path.join(root, u) : u.startsWith('/project/') ? path.join(path.dirname(episode), u.slice(9)) : null;
const server = http.createServer((req, res) => { const p = map(decodeURIComponent(req.url.split('?')[0])); if (!p || !fs.existsSync(p)) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'content-type': mime[path.extname(p)] || 'application/octet-stream', 'cache-control': 'no-store' }); fs.createReadStream(p).pipe(res); });
await new Promise((r) => server.listen(0, '127.0.0.1', r)); const port = server.address().port;

const puppeteer = require('puppeteer-core'); let exe = process.env.CHROME_PATH, extra = [];
if (!exe) for (const c of ['/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome']) if (fs.existsSync(c)) { exe = c; break; }
if (!exe) { const chromium = (await import('@sparticuz/chromium')).default; exe = await chromium.executablePath(); extra = chromium.args; }
const gpuFlags = process.env.HSB_GPU ? ['--use-gl=angle', '--ignore-gpu-blocklist'] : ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'];
const browser = await puppeteer.launch({ executablePath: exe, headless: 'shell', args: [...extra, ...gpuFlags, '--no-sandbox', '--disable-dev-shm-usage', '--autoplay-policy=no-user-gesture-required'] });
const page = await browser.newPage(); await page.setViewport({ width: 1080, height: 1920 });
page.on('pageerror', (e) => console.error('PAGE ERROR:', e.message)); page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) console.error('console.' + m.type() + ':', m.text()); });
await page.goto(`http://127.0.0.1:${port}/?scale=${scale}`); await page.waitForFunction('window.__ready===true', { timeout: 120000 });
const name = `video_${String(f0).padStart(4, '0')}-${String(f1).padStart(4, '0')}${preview ? '_preview' : ''}.mp4`, outFile = path.join(outDir, name);
const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', '30', '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', preview ? 'ultrafast' : 'medium', '-crf', preview ? '24' : '15', '-pix_fmt', 'yuv420p', '-r', '30', outFile], { stdio: ['pipe', 'inherit', 'inherit'] });
const t0 = Date.now();
for (let i = f0; i <= f1; i++) { const b64 = await page.evaluate((n) => window.renderFrame(n), i); if (!ff.stdin.write(Buffer.from(b64, 'base64'))) await new Promise((r) => ff.stdin.once('drain', r)); if ((i - f0) % 30 === 0) process.stderr.write(`frame ${i}/${f1}  ${((Date.now() - t0) / 1000).toFixed(0)}s\n`); }
ff.stdin.end(); await new Promise((r) => ff.on('close', r)); await browser.close(); server.close();
const mp = path.join(outDir, 'render-manifest.json'); const man = fs.existsSync(mp) ? JSON.parse(fs.readFileSync(mp)) : { segments: [] };
man.segments = man.segments.filter((s) => s.file !== name); man.segments.push({ file: name, frames: [f0, f1], preview: !!preview, scale, episode: path.basename(episode), done: true, at: new Date().toISOString() }); fs.writeFileSync(mp, JSON.stringify(man, null, 2));
console.log('DONE', outFile);
