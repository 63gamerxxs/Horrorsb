# Hook + retention grammar (what makes the reference series hold viewers)

Measured on the three reference videos (95 s / 66 s / 89 s): a NEW line of on-screen text every ~2.0 s, a new piece of information every ~5 s, a new visual state or location every ~8–15 s, and a darker/more dangerous state every ~20 s. Nothing ever sits still for more than 3 s.

## The 0–5 second hook (mandatory, 3 beats)
1. **Frame 1 (0.0 s): already in motion + a voice.** No fade-in, no establishing shot. The first-person hand is moving (pushing clothes, grabbing a handle) while a voice line is already playing. A small place/time card sits top-left ("FRIDAY · 9:50 PM / Harbor Point Mall — Mothwell" in the reference) so the viewer knows where/when in 1 second.
2. **0.5–3 s: the wrong thing.** A line that cannot be explained yet ("The mall is closing in 10 minutes", "The feed is running 3 minutes ahead") or a visual that is off. Viewer asks: what? who? why?
3. **3–5 s: the BOOM.** A hard sound hit + a visual confirmation that something is wrong (silhouette with glowing eyes, a character reacting, a message that should be impossible). Subtitle goes hot red on the key word. After this the story proper starts. The viewer's dopamine curve: question (0–3) → spike (3–5) → promise of answers.
Never open on: scenery, a title, a slow fade, silence, someone walking down an empty corridor.

## 85 s timeline template (adapt, keep the rhythm)
| time | purpose | typical content |
|---|---|---|
| 0–5 | HOOK | above |
| 5–15 | setup the rule | someone gives a warning / an unexplained instruction; first NPC face-to-camera; a sound the NPC denies hearing |
| 15–30 | wrongness | PA/phone/NPC reveals a SECRET RULE that reframes everything ("Mr. X means lockdown. It's already inside.") |
| 30–45 | forced move | run / hide / enter the dangerous space; movement through 2–3 environments; subtitle red keywords |
| 45–60 | darkness | screen goes black or nearly black for 1–4 s, audio keeps pulsing (breath, heartbeat, steps beyond the curtain), a threat passes close |
| 60–75 | phone act | phone raised; chat with a contact that is slightly wrong (typing oddly, answers too fast, knows too much), "Read", typing animation, one image/voice-note bubble |
| 75–79.5 | last image | the entity silhouette with white eyes at distance, or the second identity reveal; whisper line ("please open.") |
| 79.5–85 | CHOICE CARD | blurred last frame, big title, two coloured buttons with icons, OR between, "Comment for Part N", "Follow @handle for more". Ambient drone continues (no silence). Buttons pop in staggered (0, .45, 1.0, 1.7, 2.0 s). |

## Devices copied from the references' structure (techniques, not content)
- **Chunked subtitles that cliff-hang mid-sentence**: "Don't make a sound." → "…who you hear." (the key word appears alone, coloured). 1–4 words per chunk, ~2 s each, centred ~72% down the frame.
- **Colour-coded speakers**: hero white, NPC yellow, friend/phone pink, threat/danger words hot red-orange.
- **Secret rule / code word** the viewer must learn (instantly makes them rewatch).
- **Contradicting sources**: in part 3 the guard says the friend is fake and the friend's message says "don't trust the guard" → the end-card choice is "WHO DO YOU TRUST?". Always build the cliffhanger from two contradicting sources, never from a random danger.
- **Identity test** via phone ("what's your favorite food?") — viewers love verifying; use one per episode.
- **Recurring entity** appears 3–4 times, always in a different frame position, never moving closer in view until the last shot.
- **Typed-message tells**: the message's wrong grammar/capitalisation is itself clue ("That's not how Theo types").
- **Continuation**: part N opens with a "PART N / You chose: X" card (top-left, 4 s) then continues directly from the chosen branch; unselected branch is never shown.
- **Choice card = two verbs**, concrete, different outcomes ("STAY HIDDEN / OPEN SHUTTER", "OPEN IT / IGNORE HER", "THE GUARD / THEO").

## Pacing laws
- Dialogue/subtitle density ≥ 30 chunks per 85 s. Never more than 2.5 s without a new chunk or a new visual event.
- Locations: 3–4 spaces per episode, each entered by continuous first-person movement (no cuts except fades to black).
- No filler shots: no clocks, bowls, empty doors, random look-arounds. Every glance has a story reason (a sound, a message, a rule).
- Every 10 s end on an open question; every answer must create a bigger question.
- Quiet is only allowed as a 0.4 s pre-hit hold. The drone/ambience bed never drops.
