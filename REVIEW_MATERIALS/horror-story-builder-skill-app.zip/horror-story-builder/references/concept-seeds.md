# Concept seeds (invent fresh ones each run; never reuse the reference story: no mall, no clothing store, no "Mr. Lockwood", no Theo/Jason, no voice-cloning guard, no doorbell-keys story)
Each of the FIVE concepts shown to the user must have: Title · Premise (1 line) · Main mystery · 5-second hook (exact first image + first spoken line + the boom) · Suspense engine (the secret rule + the entity's behaviour) · Two contradicting sources for the cliffhanger · Ending choice pair. Keep each concept ≤ 70 words. Mix settings: one WATER setting, one confined/mechanical, one domestic, one public-after-hours, one outdoors/night.

Seeds to riff from:
1. **Night Ferry** — last ferry, engine hum, the PA calls passengers by name before they board. (water) Hook: "Passenger Dana Reyes, please return to your seat." — you are Dana, you are standing on the dock.
2. **Floor 0** — lift keeps stopping at a floor that isn't on the panel; the lift voice and a text from the building manager disagree about which stairs are safe.
3. **Drive-Thru Wash** — stuck mid car-wash in the dark; water curtain; something stands behind the foam. (water)
4. **Late Bus 41** — driver announces stops that don't exist; passenger's phone shows a different route than the driver's map.
5. **Substation Blackout** — street lights go out house by house toward yours; neighbour texts "don't look at the transformer".
6. **Pool After Close** — pool lights switch on one by one; the water level rises each time you look away. (water)
7. **Night Library Return Slot** — the book-return chute delivers notes in your handwriting.
8. **Cold Storage** — warehouse freezer, red emergency lights, a coworker's voice from the intercom says the door is open; the radio says it's a trap.
9. **Hotel Do-Not-Disturb** — the sign on your door flips itself; the front desk says nobody is on your floor, the room phone says otherwise.
10. **Lakehouse Dock** — the rowboat is in a different place every time the security feed refreshes. (water)
Rules for every concept: danger must be understandable (clear rule), ending a concrete 2-option dilemma, no graphic gore, no real brands/people.
