# Typography + UI (deliberately different from the reference series)
The references use a high-contrast chunky SERIF in cream/yellow with a dark outline. We do NOT. Bundled fonts (OFL, in /fonts, loaded by engine/index.html):
- **Bebas Neue** — place/time card, part card, end-card title, buttons (tall condensed caps).
- **Barlow Condensed ExtraBold** — subtitles (UPPERCASE condensed sans, 112 px at 1080 wide, black 16 px outline, soft drop shadow, pop-in scale .88→1 over 4 frames).
- **DM Sans** — phone UI.
Subtitle colours (our mapping): hero #fff, NPC #ffd45e, friend/phone #ff9ccf, threat #ff4d2e, system #7fe3ff; hot words in [[double brackets]] render #ff4d2e. Position: centred at 72 % height, max 86 % width, max 2 lines, safe margins 54 px. Never a grey caption box. Never DejaVu/system fonts.

## Cards
- Place/time card (0–4 s, top-left): line 1 Bebas 64 px cream "FRIDAY · 9:50 PM"; line 2 Barlow 34 px amber "PLACE — SUBLOCATION". Slide-in 30 px.
- Part card (episode 2+, 0–5 s): "PART 2" Bebas 84 px + "YOU CHOSE: <choice>" with the choice in hot red.
- End card (last 5.5 s: 79.5–85.0): blurred+darkened live frame, title Bebas 190 px (two lines, cream), button A (green, icon), "OR" (amber), button B (red/blue, icon), "COMMENT FOR PART N" (amber part name), "FOLLOW @HANDLE FOR MORE". Buttons 820×170 px, radius 40, 2-tone border, drop shadow, icon+label centred. Icons are canvas-drawn (door, mute, hand, phone, eye, run). Staggered pop-in. Ambience continues under it.

## Phone UI (engine/lib/phone.js)
Dark chat app: status bar (clock, battery, red battery when low), header with round initial avatar, name, green "Active now". Incoming bubbles dark grey (#20242e), outgoing blue (#3b82f6), 25 px DM Sans, receipts "Delivered"/"Read" in grey, input field with "Message" placeholder that types out letter by letter before an outgoing bubble sends, round send arrow that turns blue while typing, image bubble (a tiny dark scene thumbnail), voice-note bubble (play button, waveform, pink progress while "playing"). Messages arrive with a 0.25 s slide-up. Timestamps in the status bar progress through the story (9:58 → 10:01 → 10:07) — time passing is a tension tool.
Message style: lowercase, typos, ALL CAPS panic, one-word replies; the "wrong" message has formal grammar.
