# What was wrong with doorbell_cam_ep1.mp4 (v2.1.0 output) vs the reference series — every item is now a rule
Measured/observed on the 85 s render.

| # | Doorbell EP1 problem | Reference behaviour | Rule now |
|---|---|---|---|
| 1 | Characters are cubes/voxels with flat faces and block hands | Smooth spheres/cylinders, glossy black eyes with highlight, round hands | Use engine/lib/character.js only. No box heads, no voxel people. |
| 2 | Opened on a static door for 12 s; first human appears on a phone thumbnail at 6 s | Character, voice and place card inside 1 s; boom + wrong thing by 5 s | Mandatory 3-beat hook (hook-and-retention.md). A face or hand-in-action by 1 s. |
| 3 | 0–44 s is door / bowl / clock / peephole / empty blue room — 4 filler glances with no story reason, 20–40 s has no dialogue | New text every 2 s, new info every 5 s, new location every ~10 s | Banned shots: clocks, bowls, empty doors, unmotivated look-arounds. Max 2.5 s without a subtitle chunk or visual event. |
| 4 | Single location, no movement through space, no escalation, ends on a chat through a door | 3–4 locations, run/hide/phone/dark acts, entity glimpses | Beat template: setup → rule → forced move → darkness → phone → last image → choice. |
| 5 | Subtitles: small white/grey DejaVu text in a grey box, same style for every speaker, full sentences | Big bold outlined text, colour per speaker, 1–4 words, red keyword | Barlow Condensed ExtraBold 112 px, outlined, speaker colours, [[hot]] words, chunked. |
| 6 | Phone is a plain rectangle held by grey block hands; UI is a CCTV card | Phone with real chat UI, bubbles, typing, receipts, voice note, finger ellipsoids, DOF blur behind it, REST/READ poses | engine/lib/phone.js + fp.js poses; bloom on screen; DOF when raised. |
| 7 | Hands are grey boxes, no sleeve, appear only with the phone | Teal-sleeved cylinder arm + sphere hand from bottom-right, left hand for actions | Hands per fp.js. Hands also push doors/racks/push-bar in the story. |
| 8 | Lighting: one warm lamp vs blue split, flat faceted shading, no fog/dust/volumetrics/grain/vignette | Long soft shadows, light cones, green exit glow, red practicals, grade, bloom, blur | Light kit in atmosphere.js + post.js grade. Minimum 1 shadow-casting spot, fog, dust, vignette, grain, bloom. |
| 9 | Audio −23.4 dB mean (references −16), long near-silent stretches (20–35 s, 45–55 s, 80–85 s at −32 dB), nearly no sub bass bed | Continuous drone, peaks −1 dB, loud endings, end card keeps ambience | Bed layer mandatory, verify.sh fails on >0.4 s gaps and loudness outside −18…−11 LUFS. |
| 10 | End card: system font, flat red/blue rectangles, tiny "Follow for Part 2", sub-line "Tap to…" | Big title, icon buttons, OR, "Comment for Part N", follow handle, staggered pop-in on blurred last frame | overlay.js endCard. |
| 11 | No time/place card, only a notification banner and a caption "feed is running 3 minutes ahead" in grey | Time/place card top-left from 0 s | Always add placeCard. A banner can be an extra hook, not a replacement. |
| 12 | Camera feels like film shots (swing to wall clock, peephole circle, rooms through lens) rather than a person | Continuous walking, bob, glances motivated by sound/message | One FirstPerson rig; no peephole/lens overlays; glances only toward a sound/message source. |
| 13 | No second character on screen until 58 s; stranger is a cube; no mouth animation | Characters talk face-to-camera with mouth + arm gestures | Mouth driven by envelope.py output; NPCs on screen by 8–12 s. |
| 14 | Cliffhanger = "open or stay silent" with nothing at stake | Two contradicting sources → "who do you trust" / concrete danger | Cliffhanger must come from a contradiction or a concrete threat the viewer has seen. |
| 15 | Style drift: fonts and shapes invented per scene; not reproducible without the reference video | — | This plugin bakes the style into engine/ code and the bible: no reference video needed. |
