# Visual bible (measured from the three reference videos; they are NOT needed at runtime)

## One-line look
Chunky "poly" toy-world: hard-edged simple blocks for buildings/props, perfectly SMOOTH spheres/cylinders for people and round things, realistic light/shadow/fog on top. Not low-poly (no faceted spheres), not hyper-real.

## Characters (every NPC, built by engine/lib/character.js)
- Head: smooth sphere, slightly taller than wide. Eyes: two glossy black spheres + one tiny white specular dot each (the "alive" detail). Nose: small skin-tone sphere. Mouth: thin dark ellipse that opens into an "o" when speaking (drive from the voice loudness envelope, tools/envelope.py). No eyebrows, no ears needed.
- Hair: one smooth shape (bun = hair cap + sphere; short = cap; uniform cap = navy half-sphere). Hard black, glossy.
- Torso: smooth capsule squashed front-to-back, plain colour, tiny detail (badge, radio) as a small box.
- ARMS = cylinder with a SPHERE at the shoulder and a bigger SPHERE hand. LEGS = cylinders. FEET = one small sphere stretched forward at the FRONT of the ankle. Everything smooth.
- Proportions: ~1.8 units tall, head ≈ 1/7.5 height, big hands, short stubby readable silhouette.
- Palette: saturated mustard/blue/red/green shirts, near-black trousers, skin tones from tan to deep brown. Every character readable as a silhouette.
- Animation: walk = leg swing ±0.55 rad + opposite arm swing + 2 cm body bounce; idle = breathing sway + slow head tilt; talking = mouth open/close by audio envelope + small arm gestures; they look at the camera when addressing the player (head turns to the camera).
- THE ENTITY (recurring threat): pure black silhouette, no face detail, TWO GLOWING WHITE OVAL EYES. Seen through shutter slats / doorways / dark corridors, usually standing still, usually far. Eyes visible in darkness are the strongest image in the series. Never lit, never explained early.

## World
- Hard-edged boxes: floor tiles (large two-tone), walls, counters, shelves with chunky colour slabs as goods, signs, doors with a vertical light-grey glass slit and a push-bar, clothes racks, round green plants made of 3 spheres, curtains (smooth sine wrinkles), roller shutters with horizontal slats.
- Detail only where silhouette or interaction needs it. No textures except floor tile canvas, signs and phone UI.
- Always include readable environmental text (shop sign, EXIT sign, "FITTING ROOMS", sale boards): it tells place, gives wayfinding and makes the world feel real.

## Camera (first person, ONE camera)
- Eye height 1.6 m, vertical FOV ~78° (wide, a lot of room visible, slight "GoPro" feel). Portrait 9:16.
- Walking: 1.7–2.2 Hz bob, ±3 cm vertical, ±2 cm lateral, ±0.5° roll; stops bob when still; constant breathing micro-sway.
- Hands: own right forearm in a coloured sleeve (teal) coming from the bottom-right corner, cylinder arm + sphere hand; left hand appears only for actions (pushing a clothes rack, touching a door, pushing the push-bar).
- PHONE (the main story device): three states — hidden, REST (bottom-right corner, tilted ~20°, screen glowing, scene still visible: used while walking/talking) and READ (raised centre frame, filling ~55–60% of frame height, background softly blurred by depth of field, four dark finger ellipsoids on the right edge and a thumb on the left edge, fingers are dark blue-grey silhouettes lit only by the screen). Raise it when a message arrives, lower it to REST when the player needs to look around again.
- Camera does turn/look/glance toward sounds before reveals, and goes to black (fade) for 1–4 s when hiding or when the lights die — audio continues.

## Light, colour, shaders
- Materials: MeshStandardMaterial, roughness 0.5–0.9, metalness ~0, flat colours, soft PCF shadows (radius ~4–5, 1024–2048 maps). Long soft diagonal shadows on floors (ceiling track spots) are a signature of the look — keep at least one shadow-casting spot per scene.
- Act 1 (normal): neutral/warm commercial light, bright, saturated, readable. Act 2: fill drops, pools of light from ceiling track spots with faint volumetric cones. Act 3: near-dark, practical colours only: GREEN exit-sign glow (cyan-green fill on walls), restrained RED corridor practicals, BLUE-WHITE phone glow on hands/fingers, hard white light through shutter slats.
- Shadows are never crushed to pure black (grade lift +0.012). Teal in shadows, warm in highlights, saturation 0.92, vignette 0.4, film grain 0.035, bloom 0.35 (phone screen, signs, eyes), slight chromatic aberration at the frame edge. Fog: exponential, density 0.03–0.06, colour near-black teal.
- Water (when the story has it): three.js Water shader with a procedural ripple normal map, dark teal body colour, sun/spot glints, slow time scale 0.6, fog on. Bank/rim made of simple blocks. See engine/lib/water.js.
- Atmosphere: sparse round dust motes drifting through light cones, light slats through blinds, occasional flicker (lights fail in the dark act).

## Format
1080×1920 (references are 720×1280; CPU-only machines may render at scale 0.6667 = 720×1280 then upscale in assemble.sh), 30 fps, 85.000 s, 2550 frames.
