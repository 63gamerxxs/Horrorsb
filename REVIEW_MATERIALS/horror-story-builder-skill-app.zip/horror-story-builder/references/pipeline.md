# Production pipeline (token-lean, resumable)

## 0. Preflight (once per session, one batched bash call)
`bash engine/../tools/preflight.sh` checks: node ≥18, ffmpeg, python3+numpy, `engine/node_modules` (else `cd engine && npm install`), a Chrome/Chromium (CHROME_PATH, system chrome, or the bundled @sparticuz/chromium), `ELEVENLABS_API_KEY` or ElevenLabs connector, Google Drive connector. Report one line per item. A missing renderer or voice tool is a blocker: say it, stop before final render. Software WebGL (SwiftShader) works but is slow (≈0.5 s/frame at 360×640, much slower at 1080p): on CPU-only machines render finals at `--scale 0.6667` (720×1280, same as the references) and let assemble.sh upscale; with a GPU set `HSB_GPU=1` and render 1080×1920.

## 1. Save structure (Google Drive `VIDEO_PROJECTS/<Title>_E<n>/`)
project/ (episode.js, script.json) · voices/ · audio/ (sfx, mix) · renders/ · final/ · checkpoints/ · project-state.md · story-bible.md · render-manifest.json
Locally the same tree under `./VIDEO_PROJECTS/...` first. After EVERY milestone (concept chosen, script locked, each voice batch, each scene render, mix, final, QC) upload the changed files with the Google Drive connector (`tool_search("google drive")` → create_file / update_file), read back the file id/metadata, and only then report SAVED. If Drive is unavailable say "Drive sync did not occur" and keep local checkpoints.

## 2. Steps (one tool call per step wherever possible)
1. **Concepts** (only on /horrorsb with no project): five concepts, STOP (see concept-seeds.md for the format).
2. **Lock**: logline, entity rule, secret rule, two contradicting sources, cliffhanger pair, location list (3–4), 85 s beat sheet from hook-and-retention.md. Write `story-bible.md`, `project-state.md` with `NEXT ACTION`. Checkpoint.
3. **Script**: `script.json` from engine/script.template.json — ≥30 subtitle chunks with who/hot words/timing, voice assignment, sfx, beds, choice card, place card. Checkpoint.
4. **Voices**: ElevenLabs per line → wav → measure duration → fix `t1` → envelope json. Checkpoint + upload.
5. **SFX/beds**: `python3 tools/synth_sfx.py kit --out audio/sfx` (+ ElevenLabs SFX where available). Build `cues.json` (from script.json) → `python3 tools/mix.py cues.json audio/mix.wav`. Checkpoint.
6. **Scene code**: copy engine/demo/episode.demo.js to project/episode.js; build the locations with lib/kit.js, characters with lib/character.js, body/phone/left-hand tracks, light cues, entity visibility, fade-to-black ranges. One file. Imports use absolute `/engine/lib/...` URLs.
7. **Preview** (cheap): `node engine/render.mjs --episode project/episode.js --out renders --preview --frames a-b` for ONE contact sheet of 12 frames (ffmpeg tile) per act. Check: hook at 0–5 s, POV law, subtitle legibility, phone readable, darkness not pure black. Fix and re-render only the failing range.
8. **Final render** per act in segments: `--frames 0-749`, `750-1499`, `1500-2549` (add `--scale 0.6667` on CPU). Each writes renders/video_a-b.mp4 + render-manifest.json. Never re-render a finished segment unless its inputs changed. Upload each segment as it finishes.
9. **Assemble + QC**: list segments in `segments.txt` (`file 'renders/video_0000-0749.mp4'` …) then `bash tools/assemble.sh segments.txt audio/mix.wav final/<title>.mp4` → loudnorm, exact 85 s/2550 frames/1080×1920 + `verify.sh`. Then view ONE contact sheet (12 frames) and run the POV/hook checklist in agents/horror-qa-reviewer.md. Fix → re-run only what changed.
10. **Deliver**: final MP4 path + Drive link, verified runtime/frames/loudness, `NEXT ACTION: await viewer's choice` and the two branch labels.

## Token/time rules
Read each reference file once per session; never paste code back into chat; batch tool calls; preview at 1/3 scale, final once; no repeated full-frame image views (contact sheets only); do not re-research or re-install; keep status updates to DONE / SAVED / NEXT.

## Continuation
`/horrorsb-continue`: read project-state.md + story-bible.md, ask nothing, set `partCard` = "PART n+1 / You chose: <label>", open on the chosen branch's first action in the same location and clothes. Record the choice; never merge branches.
