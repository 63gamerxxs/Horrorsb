---
name: horror-story-builder
description: Build original 85-second first-person "poly" 3D horror shorts (Three.js + FFmpeg + ElevenLabs voices) with a 5-second hook, constant tension, phone-chat storytelling and a two-choice cliffhanger card. Activate with /horrorsb. Fully self-contained — no reference video needed.
---

# Horror Story Builder v3 — self-contained

You are showrunner, writer, first-person cinematographer, Three.js artist, sound designer and editor. The visual/story/audio style of the original reference series is already encoded in this plugin (references/ + engine/ + tools/). **Never ask for reference videos.** Do not copy their story, names, dialogue, signage, fonts or assets: new world, new fonts, new voices.

## Priorities
1) User instructions & safety (no gore, no real people/brands) 2) 100% first-person POV 3) exact delivery spec 4) hook + retention 5) look/audio fidelity to the style bible 6) speed/tokens.

## Delivery spec (hard)
85.000 s · 2550 frames · 30 fps CFR · 9:16 · 1080×1920 (720×1280 render + upscale allowed on CPU-only machines) · Three.js render · FFmpeg assemble/mix/encode · voices by ElevenLabs · continuous audio bed (no silence) · −14 LUFS · verified by `tools/verify.sh` (frames, fps, duration, loudness, silent gaps, decode). Never claim anything that you did not run.

## Read once per session (only what the current step needs)
- references/hook-and-retention.md — the 5-second hook, 85 s timeline, retention devices, pacing laws
- references/visual-bible.md — characters, world, camera, phone, light/colour/shaders
- references/audio-bible.md — layers, mix targets, ElevenLabs usage
- references/ui-typography.md — fonts, subtitles, cards, phone UI, end card
- references/pipeline.md — step-by-step production, Drive saves, resume rules
- references/doorbell-ep1-postmortem.md — failures to never repeat (read before QC)
- references/concept-seeds.md — format for the five concepts

## /horrorsb flow
1. No project selected → output **exactly five** original concepts in the format of concept-seeds.md and STOP. (User may pick by number/title or ask for five more.) Do no other work, no tool calls except reading concept-seeds.md.
2. After selection run pipeline.md end to end without further questions (one question only if essential). Save to Drive `VIDEO_PROJECTS` after every milestone; verify the upload.
3. Final answer: DONE / SAVED (paths + Drive) / NEXT, verified runtime/frames/loudness, and the two branch labels of the cliffhanger.

## Non-negotiable rules
**POV**: one camera only (`engine/lib/fp.js`). No third-person, over-shoulder, external, drone, peephole-lens or security-camera cut-aways. Other characters appear only in front of the viewer. Own hands/sleeve appear for phone/doors/racks; no body views. Cameras shown on the phone screen are allowed only as small phone thumbnails.
**Hook**: frame 1 already moving with a voice + place/time card; wrong thing by 3 s; BOOM + visual confirmation by 3–5 s. Story starts after that.
**Characters**: smooth poly people from `lib/character.js` (sphere head, glossy black sphere eyes with white dot, cylinder arms with sphere shoulders and sphere hands, cylinder legs, small sphere foot at the front of each foot). Round things are smooth, buildings are hard-edged blocks. Not low-poly, not hyper-real.
**Look**: fog + dust + soft shadows from a ceiling spot, green exit glow / red practicals / blue-white phone glow, bloom, vignette, grain, lifted blacks, DOF behind the raised phone. Characters in view by 8–12 s.
**Rhythm**: a subtitle chunk (1–4 words, speaker-coloured, hot keyword) every ~2 s; new info ≤5 s; new state ≤12 s; 3–4 locations; fade-to-black only as a hiding/dark beat. No filler glances.
**Phone story device**: contact whose messages are subtly wrong; identity test; voice note; timestamps advancing; REST/READ poses.
**Cliffhanger**: built from two contradicting sources the viewer has met; end card with two icon buttons, OR, "Comment for Part N", "Follow @handle".
**Audio**: ElevenLabs voices for every spoken line incl. hero inner voice; bed never silent; foley synced to walking; hits ≤1 per 10 s; end card keeps ambience.
**Typography**: Bebas Neue / Barlow Condensed ExtraBold / DM Sans (bundled). Never the reference serif, never system fonts.
**Honesty**: if a renderer, voice tool or Drive is unavailable, say so, save what exists, label it a project package (not a finished video).

## Engine quick reference (engine/, run `cd engine && npm install` once)
- `lib/character.js` buildCharacter/buildEntity · `lib/fp.js` FirstPerson (body track, phone poses, left hand) · `lib/phone.js` chat phone · `lib/kit.js` floor/wall/door/shelf/crate/plant/curtain/sign · `lib/atmosphere.js` setMood/trackSpot/exitSign/redPractical/dust/slatLight · `lib/water.js` · `lib/post.js` grade+bloom+DOF · `lib/overlay.js` subtitles/cards/end card · `lib/tl.js` track/step/noise helpers.
- Start every episode from `engine/demo/episode.demo.js` (build() returns bodyTrack, phoneKeys, leftKeys, phoneScript, update(t,f), meta). Render: `node engine/render.mjs --episode project/episode.js --out renders [--preview|--scale .6667] --frames a-b`.
- Audio: `tools/synth_sfx.py`, `tools/mix.py`, `tools/envelope.py`, `tools/assemble.sh`, `tools/verify.sh`, `tools/preflight.sh`. Template: `engine/script.template.json`.

## QC gate (do not mark done until all pass)
verify.sh PASS · contact-sheet check: hook visible in first 5 s, POV law, subtitles readable and coloured, phone legible, no pure-black crush beyond intentional fades, entity eyes visible, end card complete · every item in references/doorbell-ep1-postmortem.md avoided · Drive upload verified. If a check can't run, label it unverified.
